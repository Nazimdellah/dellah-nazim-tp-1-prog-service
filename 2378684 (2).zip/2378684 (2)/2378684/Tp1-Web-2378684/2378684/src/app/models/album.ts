export class album{
    constructor(public name: string, public imageUrl : string){}
}